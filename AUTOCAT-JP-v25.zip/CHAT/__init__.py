"""AUTOCAT JP chat package."""

